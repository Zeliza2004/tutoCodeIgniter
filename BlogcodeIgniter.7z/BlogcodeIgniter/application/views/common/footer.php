<div class="container">
  <hr>
  <footer>
    <p>&copy; Stéphanie Canuel 2020</p>
  </footer>
</div>
<script src="<?= base_url('js/jquery-2.1.4.min.js')?>" type="text/javascript"></script>
<script src="<?= base_url('js/bootstrap.min.js')?>" type="text/javascript"></script>
<?php
if (isset($script)) {
  echo $script;
}
?>
</body>
</html>
