<p class="alert alert-success" role="alert">
	L'article a été supprimé.
</p>
<p style="text-align : center">
	<?= anchor('blog/index', "Fermer", ['class' => "btn btn-default"]); ?>
</p>
