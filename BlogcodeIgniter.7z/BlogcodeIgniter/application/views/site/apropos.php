<div class="container">
  <div class="row">
    <?= heading($title); ?>
    <hr />
  </div>
  <div class="row">
    <p>Bla, bla, bla...</p>
    <p>Bla, bla, bla...</p>
    <p>Bla, bla, bla...</p>
    <p>Bla, bla, bla...</p>
  </div>
</div>