<div class="jumbotron">
  <div class="container">
    <h1><?= $title ?></h1>
    <p>Ceci est ma page d'accueil</p>
  </div>
</div>
<div class="container">
  <p>Bla, bla, bla...</p>
  <p>Bla, bla, bla...</p>
  <p>Bla, bla, bla...</p>
</div>