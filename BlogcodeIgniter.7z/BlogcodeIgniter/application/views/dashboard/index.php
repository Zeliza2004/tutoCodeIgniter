<div class="container">
	<div class="row">
		<?= heading($title); ?>
		<hr/>
	</div>
	<div class="row">
		<p>Ceci est mon panneau de contrôle</p>
	</div>
</div>
